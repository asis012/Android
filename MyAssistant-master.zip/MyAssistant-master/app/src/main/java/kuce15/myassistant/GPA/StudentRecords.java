package kuce15.myassistant.GPA;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import kuce15.myassistant.R;


public class StudentRecords extends AppCompatActivity {
    StudentDatabase myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_records);
        BackGroundTask backGroundTask=new BackGroundTask(this);
        backGroundTask.execute("get_info");
    }
}
